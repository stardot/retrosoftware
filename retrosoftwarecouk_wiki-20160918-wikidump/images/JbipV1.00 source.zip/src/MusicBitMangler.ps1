﻿
# Write-FileByte is purloined from http://cyber-defense.sans.org/blog/2010/02/11/powershell-byte-array-hex-convert

function Write-FileByte
{
################################################################
#.Synopsis
# Overwrites or creates a file with an array of raw bytes.
#.Parameter ByteArray
# System.Byte[] array of bytes to put into the file. If you
# pipe this array in, you must pipe the [Ref] to the array.
#.Parameter Path
# Path to the file as a string or as System.IO.FileInfo object.
# Path as a string can be relative, absolute, or a simple file
# name if the file is in the present working directory.
#.Example
# write-filebyte -bytearray $bytes -path outfile.bin
#.Example
# [Ref] $bytes | write-filebyte -path c:tempoutfile.bin
################################################################
 [CmdletBinding()] Param (
 [Parameter(Mandatory = $True, ValueFromPipeline = $True)] [System.Byte[]] $ByteArray,
 [Parameter(Mandatory = $True)] $Path )

if ($Path -is [System.IO.FileInfo])
 { $Path = $Path.FullName }
 elseif ($Path -notlike "**") #Simple file name.
 { $Path = "$pwd" + "" + "$Path" }
 elseif ($Path -like ".*") #pwd of script
 { $Path = $Path -replace "^.",$pwd.Path }
 elseif ($Path -like "..*") #parent directory of pwd of script
 { $Path = $Path -replace "^..",$(get-item $pwd).Parent.FullName }
 else
 { throw "Cannot resolve path!" }
 [System.IO.File]::WriteAllBytes($Path, $ByteArray)
}



# Read-FileByte is purloined from http://cyber-defense.sans.org/blog/2010/02/11/powershell-byte-array-hex-convert

 function Read-FileByte
{
################################################################
#.Synopsis
# Returns an array of System.Byte[] of the file contents.
#.Parameter Path
# Path to the file as a string or as System.IO.FileInfo object.
# FileInfo object can be piped into the function. Path as a
# string can be relative or absolute, but cannot be piped.
################################################################
[CmdletBinding()] Param (
[Parameter(Mandatory = $True, ValueFromPipelineByPropertyName = $True)]
[Alias("FullName","FilePath")]
$Path )
[System.IO.File]::ReadAllBytes( $(resolve-path $Path) )
}



# ---------------------
# MusicBitMangler.ps1 v0.1 
# jbnbeeb 13/04/15
# ---------------------

# Will run on Powershell V3 and up.. possibly earlier but untested YMMV


# Purpose: Import 3 csv files (2 reference files for note and length values + 1 tune file)
# and then output a tune data binary file for importing in to Beeb



# 3 files required for Input
# --------------------------------------------------------------------
# 
#Reference files which are imported in to hashtable key/value pairs:
# NoteVals.csv
# LengthVals.csv

# The tune file, currently limited to one monophonic melody only.
# TestTune.csv





# 1 file for output
# -------------------------------------------------------------------
# beebtesttune.bin








# Init Hashtables 
$length = @{}
$note = @{}

# Import the ref files:
$note = ((Get-Content .\NoteVals.csv) -replace ",","=")-join "`n" |convertfrom-stringdata
$length = ((Get-Content .\LengthVals.csv) -replace ",","=")-join "`n" |convertfrom-stringdata
$note.Remove("NoteName")
$length.Remove("LengthName")

# Import the tune file
$NoteArrayNew = New-Object System.Collections.ArrayList
$Tune = Import-Csv .\TestTune.csv

#Create a byte array of numbers which correspond to the notoes specified in the tune
foreach ($i in $Tune){$NoteArrayNew.Add([Byte]($note.Get_item($i.Note)))}


#Shift each of these bytes leftx4
$LS4NoteArray = New-Object System.Collections.ArrayList
foreach ($i in $NoteArrayNew){$LS4NoteArray.Add([Byte]$i -shl4)}


#Bitwise OR the shifted note bytes with their corresponding octave 
for  ($i=0 ; $i -lt $Tune.Length;$i++){$LS4NoteArray[$i] = $LS4NoteArray[$i] -bor [byte]$Tune.Octave[$i]}


#Create an array of numbers corresponding to the length of each note 

$LengthArrayNew = New-Object System.Collections.ArrayList
for  ($i=0 ; $i -lt $Tune.Length;$i++){$a = $length.get_item($tune[$i].length) ; $lengthArraynew.Add($a)} 




#Create an array of consecutive byte pairs , first byte = Note+Octave, second byte = length
$NoteOctaveLengthPairsArray = New-Object System.Collections.ArrayList
for  ($i=0 ; $i -lt $Tune.Length;$i++){$NoteOctaveLengthPairsArray.Add([Byte]$LS4NoteArray[[byte]$i]);$NoteOctaveLengthPairsArray.Add([Byte]$LengthArrayNew[[byte]$i])}


#Output NoteOctaveLengthPairsArray to a binary file for including in BeebAsm file
Write-FileByte -ByteArray $NoteOctaveLengthPairsArray -path .\beebtesttune.bin
