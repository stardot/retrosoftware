===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 6 KB video RAM (#8000-#97FF)

===================================================================
Keys:
===================================================================

	Z - Left
	X - Right
	; - Up
	. - Down
      RET - Fire

      DEL - Freeze game
     COPY - Unfreeze game

 	E - End game

The joystick can be selected in the intro screen.

===================================================================
Joystick (optional JOYMMC):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick (optional JOYKEY):
===================================================================

The joystick is connected parallel to row 1 of the keyboard matrix.

    nokey - fire
	G - Right
	3 - Left
	- - Down
	Q - Up

===================================================================
AtoMMC version:
===================================================================

F14RUN  = Basic introscreen
F14SCR  = Backscreen
F14CODE = Gamecode
LEVEL1  = Level1 data
LEVEL2  = Level2 data
LEVEL3  = Level3 data
LEVEL4  = Level4 data

To start the game, type: *F14RUN

===================================================================
Source:
===================================================================

The sourcefiles are compiled with the CC65 cross compiler.
Make sure that the files CA65.EXE and LD65.EXE are in a 
directory called BIN in the same directory as the source.
 
Type MAKE F14CODE to compile the program.

An assembler listing is created in the F14CODE.LST file.
