-------------------------------------------------------------------------------
Mixed Grill March v1.01
http://www.retrosoftware.co.uk/mixedgrillmarch

Built using Steve O'Leary's SWIFT integrated development environment:
http://www.retrosoftware.co.uk/swift

To be assembled with Ophis assembler:
https://hkn.eecs.berkeley.edu/~mcmartin/ophis/

Markie, our hero, is about to tuck in to the pub's last mixed grill.
But MIXED GRILL MAN is distraught!
He steals Markie's mixed grill and makes a run for it.
Not even walls will stop him!
Match his pose as you go through the walls after him, then waggle your
arms to catch him.
GET YOUR MIXED GRILL BACK!

Copyright 2012 Jools Henn

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

-------------------------------------------------------------------------------



Mixed Grill March - Source Code
-------------------------------

Firstly, apologies for the state of the code. It's not meant to be pretty, the fact that it works is good enough :)

Which files do what, then?



*** MixedGrillMarch.swfprj ***
This is the project file for the SWIFT IDE. Load this one into Swift.


*** MainSource.txt ***
Just what it says... it's the whole source code for the game (all 75k of it!)
This, combined with the gfx files, builds the MGMGAME file.


*** Boot2.txt ***
For disc version only.
Executed on control-break. !BOOT file, Loads MGMLOAD


*** Basic_Loader.bin ***
For disc version only.
BASIC loader file, with embedded loading screen code.


*** Boot.txt ***
For disc version only.
This file is "MGMEXEC". It's *EXEC-ed by the basic loader.
It loads the main game, and the relocation code, then executes the relocation code which also runs the game.


*** Relocate.txt ***
For disc version only.
Source code for relocation routine.


*** Basic_Loader_tape.bin ***
For tape version only.
To construct the tape version of the game, you need two files - this file as "MIXED",
followed by the game code as "MGMGAME" (from the disc image). The load / execution address of MGMGAME should be E00.


*** sprites.bin ***
*** background_stuff.bin ***
*** numbers_etc.bin ***
These are the swift sprites collections that contain the graphics for the game. The names should be
fairly self-explanatory. These aren't actually used by the game, though - they contain a lot of useless
header bytes added by the swift sprite editor...


*** sprites_raw.bin ***
*** background_stuff_raw.bin ***
*** numbers_etc_raw.bin*** 
...so these files are the above files with the header bytes removed. I do this manually in a hex editor.
These are the files that are merged into the main MGMGAME file.

There's a corruption issue with Swift. If you edit the graphics files and save them, then they're corrupted,
and won't load in again properly. You can fix the corruption by changing the second byte in file from "00" to "20" hex.


*** loader/FreewareLoader_edit.ssd ***
Disc image containing the files used to make the loaders.


*** MixedGrillMarch.ssd ***
Final disc image created by Swift.
