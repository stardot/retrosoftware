MazezaM In Da 80s for the BBC Micro Model B
-------------------------------------------

A quick 10 levels, knocked up in honour of In Da 80s, 2011 at the
Lass O'Gowrie in Manchester.

On the way to the event I came up with the idea of a themed set, whereby
the levels would be solvable in between 80 and 89 moves.
The original ones which I designed on the train were put into the game while
esconced in the Snug, after much use of the colloquial Anglo-Saxon which 
was entirely directed at my unforgiving work pc.

Due to conditions which I attribute entirely to being over-tired, it turned out
that the levels were actually easier than I at first thought.
(Although, as usual, full credit goes to Michael for getting through them far
quicker than I can myself.)

After much rigorous play-testing I am convinced which I have a set which 
conforms to my original plan.
Level 1 can be done in 80 moves, going through to Level 10 which can be finished 
in 89.

I subsequently dispensed entirely with my usual naming conventions and have
titled each one after what I consider to be an important hardware release - (for myself) -
from that year.


Kian

MazezaM was written entirely in assembly language, using the rather splendid 'Swift' with 'Beeb-ASM'.

Any thoughts or comments are always welcome.

