#!/bin/sh
beebasm -i zcode_128.asm -di inputtemplate.ssd -do zcode_128.ssd
