#!/bin/sh
beebasm -i zcode_b.asm -di inputtemplate.ssd -do zcode_b.ssd
