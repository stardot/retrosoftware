===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 6 KB video RAM (#8000-#97FF)
- VIA

===================================================================
Keys:
===================================================================

	Z - Left
	X - Right
	; - Up
	. - Down

	S - Sound on
	Q - Sound off
      DEL - Pause
     COPY - Resume

      ESC - Kill
	R - Restart

The joystick will be enabled while playing.

===================================================================
Joystick (optional):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Tape version:
===================================================================

REPTON.CSW , Tapefile colour version for Atomulator emulator
REPTON.UEF , Tapefile colour version for Atomulator emulator
REPTON.TAP , Tapefile colour version emulator Wouter Ras
REPTON.WAV , Tapefile colour version original Atom or MESS

To start the game, type: *RUN"LOADER"

===================================================================
Disk version:
===================================================================

REPTON.DSK , Diskfile colour version for emulators

To start the game, type: *RUN"runme"

===================================================================
Source:
===================================================================

The sourcefiles are compiled with the CC65 cross compiler.
Make sure that the files CA65.EXE and LD65.EXE are in a 
directory called BIN in the same directory as the source.
 
Type MAKE REPTON to compile the program.

An assembler listing is created in the REPTON.LST file.
