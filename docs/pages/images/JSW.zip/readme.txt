===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM
- 6 KB video RAM (#8000-#97FF)

===================================================================
Keys:
===================================================================

	Z - Left
	X - Right
      RET - Jump

===================================================================
Joystick JOYMMC (optional):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

If direction is active, bit = 1

===================================================================
Joystick JOYKEY (optional):
===================================================================

The joystick is connected parallel to the first row of the keyboard
matrix according to the Dutch Atom Group standard:

 row         column
#B000        #B001
--------------------------
  0   - PB0 - #01 - Jump
  0   - PB1 - #02 - Left
  0   - PB2 - #04 - Up
  0   - PB3 - #08 - Right
  0   - PB4 - #10 - Down

===================================================================
Tape version:
===================================================================

JSW.TAP , Tapefile for emulator Wouter Ras

To start the game, type: *RUN"JSWRUN"

===================================================================
Disk version:
===================================================================

JSW.DSK , Diskfile for emulators

To start the game, type: *RUN"JSWRUN"

===================================================================
AtoMMC version:
===================================================================

JSWRUN  , Basic startfile
JSWCODE , Assembler code of game

To start the game, type: *RUN"JSWRUN"

===================================================================
Source:
===================================================================

The sourcefiles are compiled with the CC65 cross compiler.
Make sure that the files CA65.EXE and LD65.EXE are in a 
directory called BIN in the same directory as the source.
 
Type MAKE JSW to compile the program.

An assembler listing is created in the JSW.LST file.
