===================================================================
System requirements:
===================================================================

- Standard Acorn Atom
- 32 KB RAM (#0000-#7FFF)
- 6 KB video RAM (#8000-#97FF)
- VIA

- Colourboard (optional)
- Joystick (optional)

===================================================================
Keys:
===================================================================

  P - Pause
  S - Toggle sound on/off
  K - Toggle Joystick/keyboard input

  Z - Left
  X - Right
  ; - Up
  . - Down
RET - Fire

===================================================================
Joystick (optional):
===================================================================

The joystick is connected to PORTB of the AtoMMC interface with 
softwareversion 2.9. The connections are like this:

AtoMMC  Joystick
-----------------
 PB0  -  Right
 PB1  -  Left
 PB2  -  Down
 PB3  -  Up
 PB4  -  Jump
 PB5  -  nc
 PB6  -  nc
 PB7  -  nc

 GND  -  GND

===================================================================
Game:
===================================================================

Zone  1 -  3, No alien bombdropping
Zone  4 -   , Alien bombdropping
Zone 14 - 29, Alien homing bombs

===================================================================
Tape version:
===================================================================

MGALA.CSW , Tapefile for Atomulator emulator monochrome version
MGALA.UEF , Tapefile for Atomulator emulator monochrome version
MGALA.TAP , Tapefile for emulator Wouter Ras monochrome version
CGALA.CSW , Tapefile for Atomulator emulator colour version
CGALA.UEF , Tapefile for Atomulator emulator colour version
CGALA.TAP , Tapefile for emulator Wouter Ras colour version

To start the game, type: *RUN"LOADER"

===================================================================
Disk version:
===================================================================

GALA.DSK , Diskfile for emulators

To start the game, type: *RUN"runme"

===================================================================
Cheatcodes:
===================================================================

1) Start game
2) Press BREAK
3) Type the following at the BASIC prompt:

   Invulnerability to aliens:
      ?#3887=#60

4) Type OLD en the RUN

