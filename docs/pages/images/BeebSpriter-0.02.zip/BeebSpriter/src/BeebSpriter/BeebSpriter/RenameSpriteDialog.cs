﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BeebSpriter
{
    public class RenameSpriteDialog : CopySpriteDialog
    {
        public RenameSpriteDialog()
        {
            Text = "Rename sprite";
        }
    }
}
