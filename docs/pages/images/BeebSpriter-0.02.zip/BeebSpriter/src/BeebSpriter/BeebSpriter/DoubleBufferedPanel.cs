﻿using System;
using System.Windows.Forms;

namespace BeebSpriter
{
    public class DoubleBufferedPanel : Panel
    {
        public DoubleBufferedPanel()
        {
            DoubleBuffered = true;
        }
    }
}
