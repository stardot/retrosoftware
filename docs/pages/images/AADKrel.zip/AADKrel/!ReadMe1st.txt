All users:

Please look at the manual - even if you have just an initial glance through it! It is in the Docs folder along with various flyers.


Windows users:

Programs are in .SSD disc image format in the DiscImages folder suitable for BBC emulators (BeebEm etc.)


RISC OS users:

If you are using a BBC emulator you could like Windoze uses use the DFS disc images in the DiscImages directory on 6502Em or BeebIt. It is probably easier, though, to use the raw programs via the BFS filing system on BeebIt. To play Castle Blacknight see the CastBlack.BBCBElk and CastBlack.Master directories.

If on the other hand you wish to use the DESIGN KIT natively you must use the programs in the Programs directory. For Castle Blacknight see CastBlack.Arch (for RISC OS 3 and 4) or also CastBlack.Iyonix (for RISC OS 5).

