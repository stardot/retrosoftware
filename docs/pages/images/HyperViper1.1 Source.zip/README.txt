
HYPER VIPER 1.1

http://bit.ly/HyperViper

Written by Kenton Price
Enhancements for release by Paul Davis
Joystick support by Pitfall Jones

Released by Retro Software, January 2011 (v1.1 Feb 2011)
http://www.retrosoftware.co.uk/hyperviper


LICENCE

This work is licensed by Kenton Price (retrosoftware@kentonprice.com)
under the Creative Commons Attribution-NonCommercial-ShareAlike
3.0 Unported License.

To view a copy of this licence, visit
http://creativecommons.org/licenses/by-nc-sa/3.0/
or send a letter to Creative Commons, 171 Second Street,
Suite 300, San Francisco, California 94105, USA.


FILES

HyperViper1.1.asm - assembler source code
sprites.bin    - sprites and background graphics data
loader.ssd     - a base disc image containing the loader and
                 licence info
makefile       - builds the game disc from the source files


INSTRUCTIONS

To build the game you will first need to download the BeebAsm assembler 
from the Retro Software web site here:

http://www.retrosoftware.co.uk/beebasm

Place the BeebAsm executable somewhere on your command PATH or, if you
prefer, in the same directory as these source files.

If you want to use the makefile to build the game, you will also need
a suitable 'make' tool. However, use of the makefile is not mandatory.

These instructions will assume you have opened a Command Prompt / Shell /
Terminal window (depending on your operating system) and have issued the
appropriate 'cd' command to change to the directory where you installed
the source files.

To build the game using the makefile, simply enter the command:

  make

This will create a disc image called HyperViper1.1.ssd that can now be
run in your favourite emulator or transferred to a real beeb.

To build the game manually, rather than using the makefile, enter the
following command:

  beebasm -i HyperViper1.1.asm -di loader.ssd -do HyperViper1.1.ssd

If you have any questions or comments about the game, it's source code
or the build process, please visit Retro Software's Hyper Viper forum
here:

http://www.retrosoftware.co.uk/forum/viewforum.php?f=68
