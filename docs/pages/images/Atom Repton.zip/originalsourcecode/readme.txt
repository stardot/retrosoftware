REPTON.SNA is a memory snapshot from $0000-$7FFF at the time the game starts.

The entry point is $2FA0
