Castle Raider pre-release 2
---------------------------

This release contains UEF and SSD files for use with the Acorn Electron and
BBC Micro.

The game is licensed under the GNU General Public License version 3 or later.
See the COPYING file for the full license.

The source code can be obtained from the Mercurial repository at the Retro
Software site:

  http://www.retrosoftware.co.uk/hg/castleraider/

David Boddie, 2014-11-09
