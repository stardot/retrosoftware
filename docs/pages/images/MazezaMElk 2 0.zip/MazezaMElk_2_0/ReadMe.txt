MazezaM for the Acorn Electron - v2.0
----------------------------------------

New in v2.0
-----------

Now includes 'MazezaM II - Monstrous MazezaM'.
Another 39 levels designed by myself.
They lead in less gently and assume a previous knowledge of the first game.
Very naff, but functional, menu screen.

Changes from v1.1 to 1.2
------------------------
Removed some horrible ghosting during scrolling.
------------------------

Changes from v1.0 to 1.1
------------------------
Changed title screen from rather dull monochrome to a prettier Mode 1 version.
Evened up timings so that movement is more consistent.
Shortened delay loop when finishing a level. 
-------------------------

In November of 2010 I came across this game,by Malcolm Tyrrell, on
World Of Spectrum and very quickly became hooked.

The notes from the author positively encouraged conversion to other platforms
and after finishing the many other projects which I had on the go 
at the time - and a few which cropped up in-between - the Easter holidays
of 2011 finally gave me the opportunity to have a go.
During this time I wrote a version for the PC, closely followed by one for the 
TI-83/84 Plus calculators. 
The following half term I succumbed to the urge to
convert it to the BBC. While 6502 asm was never my language of choice, and not
having used it since I was at school - (how many times should one person have
to write a machine code bubble sort ???) - I managed to squeeze the program 
under a Mode 2 graphics screen with 3 bytes to spare.

The game uses the extended set of 'mazezams' provided with the ZX81 version of the game,
which Malcolm kindly made available to me, for which he still retains the copyright.

There are also 8 levels of my own design, taken from my PC remake.
This version contains a total of 38 different levels. 

Instructions
------------
The disc image can be run using ' CH."LOADER" '.

You must escape from the MazezaMs by navigating through each maze.
From the title screen, press any key to start.

Use the 'Z','X','*' and '?' keys to move.

Blocks may only be moved by pushing, not pulling.

If you should become trapped, then pressing the 'Esc' key will restart the current level,
but lose you 1 of your lives.

To quit to the title screen press the 'Q' key.

Should you be completely defeated by a particular level, then pressing zero will
skip to the next one.

For full details on the game, visit: http://www.worldofspectrum.org/infoseekid.cgi?id=0014525&loadpics=1

I hope you enjoy this game as much as I have.

Kian

MazezaM was written entirely in assembly language, using the rather splendid 'Swift' with 'Beeb-ASM'.

Any thoughts or comments are always welcome.

