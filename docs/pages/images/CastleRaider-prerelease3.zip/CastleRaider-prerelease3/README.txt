Castle Raider pre-release 3
---------------------------

This release contains UEF and SSD files for use with the Acorn Electron and
BBC Micro.

The game is licensed under the GNU General Public License version 3 or later.
See the COPYING file for the full license.

The source code can be obtained from the Mercurial repository at the Retro
Software site:

  http://www.retrosoftware.co.uk/hg/castleraider/

David Boddie, 2014-11-30


Playing the Game

The player must help the character escape the castle, ideally with some hidden
treasure.

Your character can roam the castle and its surroundings using the following
control keys:

  Z         left
  X         right
  Return    jump
  /         enter

The character may enter different parts of the castle by entering the arched
doorways that can be found in various places. While standing in a doorway,
press the / key to enter.

Alternatively, you may may using an analogue joystick with the following
controls:

  Left      left
  Right     right
  Fire      jump
  Down      enter

Select joystick controls by pressing the Fire button on the title page to start
the game. Press Space to start the game with keyboard controls.

Other keys can be used to control the game:

  S         enable sound effects
  Q         disable sound effects
  P         pause the game
  O         resume the game
  Escape    quit the game, returning to the title screen


License

Copyright (C) 2014 David Boddie <david@boddie.org.uk>
An Infukor production for Retro Software (http://www.retrosoftware.co.uk/)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

